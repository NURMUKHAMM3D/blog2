const express = require('express');
const posts = require('../blog-ejs/posts')
const app = express();

app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.render('index',{posts});
});

app.get('/new', (req, res) => {
  res.render('index1');
});

app.post('/', async (req, res) => {
  const post = {title: req.body.title, content: req.body.content}
  posts.push(post);
  res.redirect("/");
});

app.listen(3000, () => {
  console.log('Server is listening on port 3000');
});
